package com.recovery.recovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecoveryNcaApplicationTests {

	@Test
	void contextLoads() {
	}

}
