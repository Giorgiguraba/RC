package com.recovery.recovery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@org.springframework.stereotype.Controller
public class Controller {

    @Autowired
    private Service service;

    @PostMapping("/submit-form")
    public ResponseEntity<String> submitForm(@RequestBody FormDTO formDTO) {
        service.sendEmail(formDTO.getEmail(), formDTO.getSubject(), formDTO.getMessage());
        return ResponseEntity.ok("Form submitted successfully.");
    }
    @GetMapping("/")
    public String index(){
        return "succses";
    }

}
